package com.example.tugasando;

public class Config {
    public static final String BASE_URL =
            "http://192.168.0.88/penjualanmobil/";

    public static final String LOGIN = BASE_URL + "login.php";

    public static final String TAMPIL_MOBIL = BASE_URL + "Tampilmobil.php";
    public static final String TAMBAH_MOBIL = BASE_URL + "Tambahmobil.php";
    public static final String EDIT_MOBIL = BASE_URL + "editmobil.php";
    public static final String HAPUS_MOBIL = BASE_URL + "hapusmobil.php";

    public static final String TAMPIL_PEMBELI = BASE_URL + "Tampilpembeli.php";
    public static final String TAMBAH_PEMBELI = BASE_URL + "Tambahpembeli.php";

    public static final String TAMPIL_PAKET = BASE_URL + "tampilpaket.php";
    public static final String TAMBAH_PAKET = BASE_URL + "tambahpaket.php";

    public static final String TAMPIL_CASH = BASE_URL + "TampilCash.php";
    public static final String TAMBAH_CASH = BASE_URL + "TambahCash.php";


    public static final String TAMPIL_KREDIT =
            BASE_URL + "tampil_kredit.php";

    public static final String TAMPIL_KREDIT_HITUNG =
            BASE_URL + "tampilkredithitung.php";

    public static final String TAMBAH_KREDIT =
            BASE_URL + "tambah_kredit.php";

    public static final String HAPUS_KREDIT =
            BASE_URL + "hapus_kredit.php";


    public static final String TAMPIL_CICILAN = BASE_URL + "TampilCicilan.php";
    public static final String TAMBAH_CICILAN = BASE_URL + "TambahCicilan.php";
    public static final String LAPORAN_CASH = BASE_URL + "LaporanCash.php";
    public static final String LAPORAN_KREDIT = BASE_URL + "LaporanKredit.php";
    public static final String LAPORAN_CICILAN = BASE_URL + "LaporanCicilan.php";
}
